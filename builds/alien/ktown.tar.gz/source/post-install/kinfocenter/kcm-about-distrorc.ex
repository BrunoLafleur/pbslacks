[General]
LogoPath=/etc/kde/xdg/slackware_logo.png
Website=http://www.slackware.com/
Variant=Post 14.2 -current\n(packages by AlienBOB)

