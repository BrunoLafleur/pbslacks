#!/bin/bash

DEST=/opt/brave-browser-the-latest
mkdir -p $DEST
chmod +x brave-browser-the-latest.py
chmod +x brave-browser-the-latest-cron.sh

cp brave-browser-the-latest.py $DEST
cp brave-browser-the-latest-cron.sh $DEST
cp permission-dialog.glade $DEST
cp end-dialog.glade $DEST
cp brave-browser-the-latest.png $DEST
cp whatismybrowser-logo.png $DEST
cp README $DEST
cp INSTALL $DEST
cp LICENSE $DEST
cp install.sh $DEST
cp uninstall.sh $DEST

cp brave-browser-the-latest-cron.sh /etc/cron.hourly
