#!/bin/bash

rm -rf /opt/brave-browser-the-latest
rm /etc/cron.hourly/brave-browser-the-latest-cron.sh
