smooth-tasks
============

Original from: http://kde-apps.org/content/show.php?content=148813
